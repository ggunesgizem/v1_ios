
module.exports = {
  ENDPOINT_URL: '"https://loyaltycardciam.mercedes-benz.com/MBTAST/AftersalesStatusTrackerService/api/"',
  WEBAPP_ENDPOINT_SHORT :'"aftersalestracker.mercedes-benz.com"',
  CIAM_APP_ID : '"ASTA.PROD"',
  CIAM_POINT_API : '"https://api.secure.mercedes-benz.com"',
  CIAM_POINT_LOGIN : '"https://login.secure.mercedes-benz.com"',
  CIAM_CLIENTID : '"c3f3a05e-7fa3-4729-b93c-fc74fa766a68"'
}


/*
 module.exports = {
  ENDPOINT_URL: '"http://sharedsfpoc.southeastasia.cloudapp.azure.com/api/"',
  WEBAPP_ENDPOINT_SHORT :'"aftersalestracker.int.mercedes-benz.com"',
  CIAM_APP_ID : '"ASTA.INT"',
  CIAM_POINT_API : '"https://api-test.secure.mercedes-benz.com"',
  CIAM_POINT_LOGIN : '"https://login-test.secure.mercedes-benz.com"',
  CIAM_CLIENTID : '"e779fb95-2e61-4345-af18-63ab29c76556"'
}
*/
