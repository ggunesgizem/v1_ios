import mapDealerIcon from './map_dealer.png'
import parkingIcon from './parking.png'
import petrolIcon from './petrol_state.png'

export { mapDealerIcon,
         parkingIcon,
         petrolIcon }
