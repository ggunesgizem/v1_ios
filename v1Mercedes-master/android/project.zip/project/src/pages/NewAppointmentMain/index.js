import React, { Component } from 'react'
import { connect } from 'react-redux'
import VehicleListContainer from '../../containers/vehicleListContainer'
import TopBar from '../../components/TopBar'
import T from 'i18n-react'

import LocateDealer from '../LocateDealer'
import SelectAgent from '../SelectAgent'
import SelectDate from '../SelectDate'
import SelectService from '../SelectService'
import BookingSummary from '../BookingSummary'

import { selectDate, selectService, updateStage, setCurrentStage } from '../../actions/bookingAction'
import { selectDealer, selectAgent } from '../../actions/dealerActions'


import '../page.css'

class NewAppointmentMain extends Component {

  constructor(props){
    super(props)
    this.switchStage = this.switchStage.bind(this)
    this.state = {
      active : true,
      isInitLoading : true,
    }
  }

  componentWillReceiveProps(np){
    console.log("new",np);
  }

  componentDidMount() {
    window.scrollTo(0, 0)
    this.props.updateStage(0)
    this.props.setCurrentStage(0)
    this.setState({
      isInitLoading : false,
    })
  }

  switchStage(stage){
    this.props.setCurrentStage(stage)
  }

  render() {
    var newTopBar = {...this.props.topbar, props:{...this.props.topbar.props, title:T.translate("booking.title"), onClickClose:this.props.onClickBack}}
    
    return (
      <div id="newAppointmentMain" className="fsmodal" style={{heigth:'100%',width:'100%'}} >
          <div style={{height:'100%',width:'100%'}} key={""}>
            {newTopBar}
            {this.state.active ?
              <div style={{height:'calc(100% - var(--top-container-height))'}}>
                <LocateDealer isGeoActive={this.props.isActive} switchStage={this.switchStage} active={this.props.currentStageInBooking == 0} isInitLoading={this.state.isInitLoading}/>
                <SelectAgent switchStage={this.switchStage} active={this.props.currentStageInBooking == 1}/>
                <SelectDate switchStage={this.switchStage} active={this.props.currentStageInBooking == 2}/>
                <SelectService switchStage={this.switchStage} active={this.props.currentStageInBooking == 3}/>
                <BookingSummary switchStage={this.switchStage} closeModal={this.props.onClickBack} active={this.props.currentStageInBooking == 4}/>
              </div>
              :
              null
            }
          </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    latestStage: state.booking.latestStage,
    currentStageInBooking : state.booking.currentStageInBooking,
  }
}
export default connect(mapStateToProps,{ selectDate, selectService, updateStage, setCurrentStage, selectDealer, selectAgent })(NewAppointmentMain)
