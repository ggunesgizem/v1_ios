import axios from 'axios'
axios.defaults.baseURL = configs.ENDPOINT_URL
axios.defaults.timeout = 20000
