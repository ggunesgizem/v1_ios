import React, { Component } from 'react'
import { connect } from 'react-redux'
import T from 'i18n-react'
import WebDisplay from '../../components/CIAM/WebDisplay'
import { dismissWebview, showWebview } from '../../actions/webDisplayAction'
import TextButton from '../../components/TextButton'
import { Transition } from 'react-transition-group'
import { transitUpStyles, transitUpStyle , transitUpDuration } from '../../pages/App/transitions'
import './profile.css'

class ProfileContainer extends Component {

  constructor(props) {
    super(props)
  }

  componentDidMount() {
  }

  render() {
    // console.log(this.props.user)
    return (
      <div>
        <div className="settings-container">
          <div className="settings-group-container">
            <div className="settings-group-sub-header">
              {T.translate("profile.personal.name")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                {this.props.user ? `${this.props.user.firstName} ${this.props.user.lastName}` : '-'}
              </div>
              <TextButton
                buttonText={T.translate("profile.personal.button.edit")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={()=>this.props.showWebview('change-name')}
                />
            </div>
          </div>
          <div className="settings-group-container">
            <div className="settings-group-sub-header">
              {T.translate("profile.personal.email address")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                {this.props.user && this.props.user.email ? `${this.props.user.email}` : '-'}
              </div>
              <TextButton
                buttonText={T.translate("profile.personal.button.edit")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={()=>this.props.showWebview('change-email')}
                />
            </div>
          </div>
          <div className="settings-group-container">
            <div className="settings-group-sub-header">
              {T.translate("profile.personal.mobile number")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                {this.props.user && this.props.user.mobilePhone ? `${this.props.user.mobilePhone}` : '-'}
              </div>
              <TextButton
                buttonText={T.translate("profile.personal.button.edit")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={()=>this.props.showWebview('change-mobile')}
                />
            </div>
          </div>
          <div className="settings-group-container">
            <div className="settings-group-sub-header">
              {T.translate("profile.personal.password")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                **********
              </div>
              <TextButton
                buttonText={T.translate("profile.personal.button.change")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={()=>this.props.showWebview('change-password')}
                />
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps(state){
  return {
    selectedLanguage: state.language.selectedLanguage,
    webviewStatus: state.webview.status,
    user: state.user,
  }
}

export default connect(mapStateToProps, {dismissWebview, showWebview})(ProfileContainer)
