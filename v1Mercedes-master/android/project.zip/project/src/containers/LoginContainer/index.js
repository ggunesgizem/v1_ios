import React, { Component } from 'react'
import { connect } from 'react-redux'
import T from 'i18n-react'
import { logout, patchDeviceID,  } from '../../actions/initialAction'
import { selectLanguage } from '../../actions/languageAction'
// import { showRegistrationPage, hideRegistrationPage } from '../../actions/userActions'
import WebDisplay from '../../components/CIAM/WebDisplay'
import TopBar from '../../components/TopBar'
import TextButton from '../../components/TextButton'
import { dismissWebview, showWebview } from '../../actions/webDisplayAction'
import './login.css'

var durum="asdasdasd";
class LoginContainer extends Component {

  constructor(props) {
    super(props)

  this.state = { status:"A" }
  }


  showPermission(){
    cordova.plugins.deneme.permissionCheck("permissionCheck", function(response){
    
     
 
  
     //alert("Metod->"+response);
     //this.setState({status:response})
     //return ""+response;
    });
  }


  askPermission(){
    cordova.plugins.deneme.permissionAsk("permissionAsk", function(response){
    console.log(response);
    //alert(response);
    }, function(error){
    console.log(error);
    //alert(error);
    });
  }

  mobilecheck () {
    if( navigator.userAgent.match(/Android/i)){
      return "android"
    }
    else{
      if(navigator.userAgent.match(/iPhone/i)){
        return "ios"
      }
    }
  };

testm(){
  this.askPermission()
}

componentWillMount(){
  
  
}

  componentDidMount() {
    this.showPermission();
    
    //alert(navigator.permissionCheck())
    navigator.notification.confirm(
      'Uygulama deneyiminizi geliştirmek ve kullanıcı ihtiyaçlarına göre şekillendirmek için istatistiksel olarak uygulama kullanım alanları, sıklığı ve kapsamını aylık dönemlerde incelemekteyiz. Bu uygulamayı kullanarak bu analizde bulunmayı kabul etmiş sayılırsınız. Herhangi bir zamanda Ayarlar –> Servisim ekranından bu ayarı değiştirebilirsiniz.',         // message
      ()=>{this.testm()}, // callback
      ' Uygulama Analizi',           // title
      ['Tamam'] // buttonName
    )
    
      
  }
  



  // closeRegistration() {
  //   this.props.hideRegistrationPage()
  // }

  render() {
    if(this.state.status!=='A'){
          alert("is this working?.."+this.state.status)
    }
    return (
      <div id="login-container" className="login-container">
        <div style={{"height":"100%"}}>


          {this.props.topbar}


          <div className="login-title-button-container">
            <div className="login-title-group">
              <div className="login-icon" />
              <div className="login-title">
                <T.span text='login.title' />
              </div>
            </div>
            <div className="login-input-group">
              <TextButton
                buttonText={T.translate("login.register")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={() => this.props.showWebview('register')}
                />
              <button type="button" className="login-btn tocMani" onClick={() => this.props.showWebview('login')}>
                <T.span text='login.login' />
              </button>
            </div>
          </div>

        </div>
      </div>
    )
  }
}

LoginContainer.contextTypes = {
  router: React.PropTypes.object.isRequired
}

LoginContainer.propTypes = {
  logout: React.PropTypes.func,
  login: React.PropTypes.func,
  isLogin: React.PropTypes.bool,
  vehicles: React.PropTypes.array,
}

function mapStateToProps(state) {
  return {
    vehicles: state.vehicle.all,
    isLogin: state.user.isLogin,
    loaded: state.loading.loaded,
    email: state.user.email,
    selectedLanguage: state.language.selectedLanguage,
    webviewStatus: state.webview.status,
    webviewType: state.webview.type,
    // registrationView: state.user.registrationRequired,
  }
}
export default connect(mapStateToProps, { logout, selectLanguage, dismissWebview, showWebview })(LoginContainer)
