import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Transition } from 'react-transition-group'
import { transitUpStyles, transitUpStyle , transitUpDuration } from '../../pages/App/transitions'
import T from 'i18n-react'
import { selectLanguage } from '../../actions/languageAction'
import { showWebview } from '../../actions/webDisplayAction'
import TextButton from '../../components/TextButton'
import './setting.css'
class SettingsContainer extends Component {

  constructor(props) {
    super(props)

    // console.log("SettingsContainer",props);
    this.showDealerSetting = this.showDealerSetting.bind(this)
    this.dismissDealerSetting = this.dismissDealerSetting.bind(this)
    this.toggleLanguage = this.toggleLanguage.bind(this)
    this.state = {
      showDealerSetting: false,
    }
  }

  componentDidMount() {
   
  }


  showDealerSetting() {
    this.setState({
      showDealerSetting: true,
    })
  }

  dismissDealerSetting() {
    this.setState({
      showDealerSetting: false,
    })
  }

  toggleLanguage() {
    if(this.props.selectedLanguage === "TURKISH"){
      return 'ENGLISH'
    } else return 'TURKISH'
  }

  render() {
    return (
      <div>
        <div className="settings-container">
          <div className="settings-group-container">
            <div className="settings-group-sub-header">
              {T.translate("profile.settings.workshop")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                <div className="settings-group-help-text">
                  {T.translate("profile.settings.workshop preferred")}
                </div>
                {this.props.preferredDealer ? this.props.preferredDealer.Name : '-'}
              </div>
              <TextButton
                buttonText={T.translate("profile.settings.button.edit")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={this.props.showSetPreferenceModal}
                />
            </div>
            <div className="settings-group-sub-header">
              {T.translate("profile.settings.service advisor")}
            </div>
            <div className="settings-group-preferred-container">
              <div className="settings-group-preferred-text">
                <div className="settings-group-help-text">
                  {T.translate("profile.settings.service advisor preferred")}
                </div>
                {this.props.preferredAgent ? `${this.props.preferredAgent.FirstName} ${this.props.preferredAgent.LastName}` : '-'}
              </div>
              <TextButton
                buttonText={T.translate("profile.settings.button.edit")}
                paddingTop={true}
                paddingLeft={true}
                paddingRight={true}
                paddingBottom={true}
                onclick={this.props.showSetPreferenceModal}
                />
            </div>

          </div>
        </div>
        <button className="button_logout" onClick={()=>this.props.showWebview('logout')} style={{"width":"90%","position":"fixed","bottom":"80px","left":"5%"}}>
          {T.translate("profile.settings.button.logout")}
        </button>



      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    selectedLanguage: state.language.selectedLanguage,
    vehicleList : state.vehicle.all,
    preferredDealer : state.dealer.prefered,
    preferredAgent : state.agent.preferred,
    webviewStatus: state.webview.status,
  }
}

export default connect(mapStateToProps,{selectLanguage, showWebview})(SettingsContainer)
